/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_225(unsigned x)
{
    return x + 3284633928U;
}

unsigned addval_230(unsigned x)
{
    return x + 3285743255U;
}

unsigned addval_322(unsigned x)
{
    return x + 3281031256U;
}

unsigned addval_121(unsigned x)
{
    return x + 3284634440U;
}

void setval_303(unsigned *p)
{
    *p = 3277356192U;
}

void setval_177(unsigned *p)
{
    *p = 2445773128U;
}

unsigned addval_404(unsigned x)
{
    return x + 3347662997U;
}

unsigned getval_395()
{
    return 2425362516U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_335(unsigned x)
{
    return x + 3676360329U;
}

unsigned getval_447()
{
    return 3677933960U;
}

unsigned getval_208()
{
    return 3281310089U;
}

unsigned getval_293()
{
    return 3252717896U;
}

void setval_226(unsigned *p)
{
    *p = 2425540233U;
}

unsigned addval_205(unsigned x)
{
    return x + 3281112713U;
}

void setval_363(unsigned *p)
{
    *p = 3281047945U;
}

void setval_452(unsigned *p)
{
    *p = 3284314461U;
}

unsigned addval_184(unsigned x)
{
    return x + 3372798217U;
}

unsigned addval_213(unsigned x)
{
    return x + 3284306402U;
}

unsigned addval_453(unsigned x)
{
    return x + 3374891657U;
}

void setval_323(unsigned *p)
{
    *p = 3675836809U;
}

void setval_491(unsigned *p)
{
    *p = 3767355475U;
}

unsigned getval_158()
{
    return 3286272332U;
}

unsigned getval_435()
{
    return 2429651815U;
}

unsigned addval_397(unsigned x)
{
    return x + 3286280520U;
}

unsigned getval_129()
{
    return 3284304277U;
}

unsigned addval_109(unsigned x)
{
    return x + 3767093448U;
}

void setval_176(unsigned *p)
{
    *p = 3222851209U;
}

unsigned getval_137()
{
    return 3676881545U;
}

unsigned getval_336()
{
    return 3676884617U;
}

void setval_339(unsigned *p)
{
    *p = 3526935177U;
}

unsigned addval_440(unsigned x)
{
    return x + 3286272328U;
}

unsigned addval_256(unsigned x)
{
    return x + 2429651946U;
}

void setval_190(unsigned *p)
{
    *p = 3281044107U;
}

unsigned getval_180()
{
    return 3676360329U;
}

unsigned addval_139(unsigned x)
{
    return x + 2447411528U;
}

unsigned getval_116()
{
    return 3767224396U;
}

unsigned getval_174()
{
    return 2429651447U;
}

void setval_378(unsigned *p)
{
    *p = 2425409033U;
}

void setval_400(unsigned *p)
{
    *p = 3372794504U;
}

unsigned addval_318(unsigned x)
{
    return x + 3676884617U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
