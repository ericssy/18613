/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_261(unsigned x)
{
    return x + 1488139143U;
}

unsigned addval_286(unsigned x)
{
    return x + 3348125829U;
}

unsigned getval_349()
{
    return 3284633928U;
}

unsigned addval_358(unsigned x)
{
    return x + 3284631880U;
}

unsigned addval_265(unsigned x)
{
    return x + 1492237795U;
}

void setval_143(unsigned *p)
{
    *p = 3284633928U;
}

unsigned addval_380(unsigned x)
{
    return x + 1763623704U;
}

void setval_139(unsigned *p)
{
    *p = 2496104776U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_218()
{
    return 2430650696U;
}

unsigned getval_467()
{
    return 3523789465U;
}

void setval_445(unsigned *p)
{
    *p = 3234124169U;
}

void setval_363(unsigned *p)
{
    *p = 3767093339U;
}

unsigned addval_283(unsigned x)
{
    return x + 3532968329U;
}

void setval_295(unsigned *p)
{
    *p = 2425406121U;
}

void setval_498(unsigned *p)
{
    *p = 3286272264U;
}

unsigned addval_168(unsigned x)
{
    return x + 2430634440U;
}

unsigned getval_388()
{
    return 3677409673U;
}

unsigned addval_491(unsigned x)
{
    return x + 3375940237U;
}

unsigned addval_276(unsigned x)
{
    return x + 2425409163U;
}

unsigned addval_203(unsigned x)
{
    return x + 3269495112U;
}

unsigned addval_237(unsigned x)
{
    return x + 3674788233U;
}

unsigned getval_421()
{
    return 3674787465U;
}

unsigned addval_391(unsigned x)
{
    return x + 3285289261U;
}

unsigned getval_427()
{
    return 3372797577U;
}

unsigned getval_357()
{
    return 3352398240U;
}

void setval_186(unsigned *p)
{
    *p = 3525365449U;
}

unsigned getval_290()
{
    return 3286272328U;
}

unsigned getval_247()
{
    return 3223375561U;
}

unsigned getval_396()
{
    return 3529560457U;
}

unsigned getval_384()
{
    return 3674784393U;
}

unsigned addval_441(unsigned x)
{
    return x + 3372273289U;
}

void setval_482(unsigned *p)
{
    *p = 3223375513U;
}

unsigned getval_346()
{
    return 3227566729U;
}

void setval_113(unsigned *p)
{
    *p = 2495777148U;
}

void setval_284(unsigned *p)
{
    *p = 3677409673U;
}

unsigned addval_461(unsigned x)
{
    return x + 3374367368U;
}

unsigned getval_271()
{
    return 3353381192U;
}

unsigned getval_458()
{
    return 3525362313U;
}

unsigned addval_174(unsigned x)
{
    return x + 3526938253U;
}

unsigned addval_130(unsigned x)
{
    return x + 2430634314U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
